
/**
Welcome1.java
A first program in Java
 */
 class Welcome1 
{

   public  static void main(String args[]) {
      System.out.println( "Welcome to Java Programming!" );
      System.exit(0);
   }
}



// Printing multiple lines in a dialog box
import javax.swing.JOptionPane;  // import class JOptionPane

public class Welcome2 {
   public static void main( String args[] )
   {
      JOptionPane.showMessageDialog(
         null, "Welcome\nto\nJava\nProgramming!" );

      System.exit( 0 );  // terminate the program
   }
}

